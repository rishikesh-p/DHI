from rich.console import Console
from rich.theme import Theme

dhi_theme = Theme({
    "info": "bright_cyan",
    "success": "bold bright_green",
    "warning": "bold bright_yellow",
    "error": "bold bright_red",
    "system": "magenta",
    "muted": "dim white",
    "highlight": "bold bright_magenta",
    "prompt": "bold bright_blue",
    "sandbox": "bold white on red"
})

console = Console(theme=dhi_theme)
