import re
import time
from langgraph.graph import StateGraph, END
from langchain_core.messages import AIMessage
from rich.prompt import Prompt
from rich.markup import escape
from dhi.ui import console

# Import our modules
from dhi.agent.state import AgentState
from dhi.agent.llm import AI_Brain
from dhi.tools.executor import SafeExecutor
from dhi.agent.memory import MemorySystem
from dhi.agent.router import Router
from dhi.config import load_config

# Initialize Tools
router = Router()
executor = SafeExecutor()
memory = MemorySystem()

local_brain = None
cloud_brain = None

def reload_agent():
    """Dynamically reloads AI Brains based on config."""
    global local_brain, cloud_brain
    config = load_config()
    
    local_brain = AI_Brain(mode="local")
    cloud_brain = AI_Brain(mode="cloud")

# Load initially
reload_agent()

def parse_llm_output(response: str):
    code_block = re.search(r"```(?:bash|sh|python)?\n(.*?)```", response, re.DOTALL)
    if code_block:
        return code_block.group(1).strip()
    
    lines = response.strip().split('\n')
    if len(lines) == 1 and not response[0].isalpha(): 
         return response.strip()

    return None

def node_router(state: AgentState):
    decision = router.route(state['input_text'])
    console.print(f"[info][GRAPH] Route Selected: {decision.upper()}[/info]")
    return {"plan": decision}

def node_local_reasoner(state: AgentState):
    config = load_config()
    context = memory.recall(state['input_text'])

    if config.get("stateful_local", False):
        history_str = "\n".join([f"{msg.type}: {msg.content}" for msg in state.get('messages', [])[-5:]])
    else:
        history_str = "STATELESS MODE: No prior history provided to prevent local model hallucination."

    prompt = (
        f"Recent Conversation History:\n{history_str}\n\n"
        f"User Intent: {state['input_text']}\n"
        f"Context from Vector DB: {context}\n"
        f"System Context: You are Pragma-OS, a strict terminal execution engine running in an Arch Linux Bubblewrap sandbox.\n"
        f"CRITICAL RULES:\n"
        f"1. You DO NOT converse. You ONLY output executable code.\n"
        f"2. NO 'sudo', NO 'pacman', NO 'yay'. You lack root privileges.\n"
        f"3. You MUST wrap the exact bash command in a ```bash ``` block.\n"
        f"4. Do not provide explanations before or after the code block.\n"
    )
    
    if state.get('error'):
        prompt += f"\n\nCRITICAL ERROR FROM LAST ATTEMPT: {state['error']}\nFix the command to resolve this error."

    console.print(f"[muted][DEBUG] Prompt Length: {len(prompt)} characters[/muted]")
    
    start_time = time.time()
    response = local_brain.think(prompt)
    end_time = time.time()
    
    console.print(f"[muted][DEBUG] Pure LLM Inference Time: {end_time - start_time:.2f} seconds[/muted]")    
    command = parse_llm_output(response)
    
    return {
        "command": command, 
        "command_output": response, 
        "messages": [AIMessage(content=response)]
    }

def node_cloud_reasoner(state: AgentState):
    context = memory.recall(state['input_text'])
    history_str = "\n".join([f"{msg.type}: {msg.content}" for msg in state.get('messages', [])[-5:]])

    prompt = (
        f"Recent Conversation History:\n{history_str}\n\n"
        f"User Intent: {state['input_text']}\n"
        f"Context from Vector DB: {context}\n"
        f"System Context: You are Pragma-OS, a strict terminal execution engine running in an Arch Linux Bubblewrap sandbox.\n"
        f"CRITICAL RULES:\n"
        f"1. You DO NOT converse. You ONLY output executable code.\n"
        f"2. NO 'sudo', NO 'pacman', NO 'yay'. You lack root privileges.\n"
        f"3. You MUST wrap the exact bash command in a ```bash ``` block.\n"
    )
    
    if state.get('error'):
        prompt += f"\n\nCRITICAL ERROR FROM LAST ATTEMPT: {state['error']}\nFix the code."

    response = cloud_brain.think(prompt)
    command = parse_llm_output(response)
    
    return {
        "command": command, 
        "command_output": response, 
        "messages": [AIMessage(content=response)]
    }

def node_executor(state: AgentState):
    cmd = state['command']
    
    if not cmd:
        error_msg = "Error: System failed to generate an executable code block."
        console.print(f"[error][GRAPH] {error_msg}[/error]")
        return {"command_output": "", "error": error_msg, "retry_count": state["retry_count"] + 1}

    # Human-in-the-Loop Confirmation
    config = load_config()
    if config.get("require_confirmation", True):
        dangerous_commands = ["rm", "mv", "touch", "reboot", "shutdown"]
        if any(cmd.strip().startswith(d) for d in dangerous_commands):
            console.print(f"[warning]WARNING: Destructive Command Detected[/warning]")
            console.print(f"[bold red]Command: {escape(cmd)}[/bold red]")
            proceed = Prompt.ask("Execute?", choices=["y", "n"])
            if proceed == "n":
                return {"command_output": "Execution cancelled by user.", "error": None}

    console.print(f"[info][GRAPH] Executing: {escape(cmd)}[/info]")
    
    output = executor.execute(cmd)
    
    if "Error:" in output:
         return {"command_output": output, "error": output, "retry_count": state["retry_count"] + 1}

    if state.get("input_text"):
        memory.save(f"Request: {state['input_text']} -> Command: {cmd}")
    
    return {"command_output": output, "error": None}

def decide_route(state: AgentState):
    return state['plan']

def should_continue(state: AgentState):
    if state['error'] and state['retry_count'] < 3:
        return "retry"
    return "end"

workflow = StateGraph(AgentState)

workflow.add_node("router", node_router)
workflow.add_node("local", node_local_reasoner)
workflow.add_node("cloud", node_cloud_reasoner)
workflow.add_node("executor", node_executor)

workflow.set_entry_point("router")

workflow.add_conditional_edges(
    "router",
    decide_route,
    {"local": "local", "cloud": "cloud"}
)

workflow.add_edge("local", "executor")
workflow.add_edge("cloud", "executor")

workflow.add_conditional_edges(
    "executor",
    should_continue,
    {"retry": "local", "end": END}
)
